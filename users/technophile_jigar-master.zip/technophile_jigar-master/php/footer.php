<footer id="footer"><!--Footer-->
	<div class="footer-top">
	<div class="container">
	<div class="row">
	<div class="col-sm-2">
	<div class="companyinfo">
<h2><span>M</span>obicity</h2>
<p></p>
	</div></div>
		</div></div>
		</div>
		<div class="footer-widget">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<div class="single-widget">
						<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
							<li><a href="contact.php">Online Help</a></li>
							<li><a href="contact.php">Contact Us</a></li>
							</ul>
						</div>

					</div>



						<div class="col-sm-3 col-sm-offset-1">
							<div class="single-widget">
								<?php include 'newsletter.php';?>
							</div>
						</div>
					</div>
		</div></div>

		<div class="footer-bottom">
		<div class="container">
		<div class="row">
<p class="pull-left">Copyright © 2016 Mobicity. All rights reserved.</p>
<p class="pull-right">Designed & Developed by <span><a target="_blank">Mobicity</a></span></p>
				</div>
			</div>
		</div>
	</footer><!--/Footer-->
