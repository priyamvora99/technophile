<?php
session_start();
echo $_SESSION["check"][0];
?>