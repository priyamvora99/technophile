<?php
$table="speaker";
$sql="Select * from ".$table." where dvd";
echo $sql;
?>